<p align='center'>
<img src="images\garcon2.png"/>
</p>

# garcon
A machine learning tool for likely guest cancellations
